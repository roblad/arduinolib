#ifndef __fonts_h__
#define __fonts_h__

#include <avr/pgmspace.h>

// copied from http://heim.ifi.uio.no/haakoh/avr/a
//const int font_count = 47;
extern unsigned char PROGMEM myfont[][5];
extern unsigned char PROGMEM my2font[][8];
extern unsigned char PROGMEM my3font[][6];
#endif

#ifndef __images_h__
#define __images_h__

#include <avr/pgmspace.h>

extern unsigned char PROGMEM Arduino_logo[];

#endif

HT1632c
=======

Arduino Library for using boards running the HT1632c driver chip, like the ones from Sure Electronics. It is based in the work by a lot of people in the Arduino community, I just made some bug fixes and the packaging as library. I used it in the making of the AOAP book made with A. Goransson and for an article for Elektor Magazine.